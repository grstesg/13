package main

import (
	"crypto/rand"
	"math/big"
	"testing"
)

// BenchmarkGPUSearchThroughput runs the search kernel for a fixed number of
// rounds and reports steady-state throughput. It targets a hash160 that will
// not be found, so the kernel does full work every round.
func BenchmarkGPUSearchThroughput(b *testing.B) {
	if n, err := gpuDeviceCount(); err != nil || n < 1 {
		b.Skipf("no CUDA device available: %v", err)
	}

	// Random target hash160 that will not be found. Using a real key risks the
	// kernel setting d_found_flag once and then short-circuiting every later
	// iteration, which would inflate throughput numbers by orders of magnitude.
	target := make([]byte, 20)
	rand.Read(target)

	mult := gpuSearchWalkMultiple()
	nWalks := targetWalks
	if nWalks < mult {
		nWalks = mult
	}
	nWalks = (nWalks / mult) * mult

	seeds := make([]byte, nWalks*32)
	for i := 0; i < nWalks; i++ {
		var off *big.Int
		if i == 0 {
			off = big.NewInt(0x100000)
		} else {
			b := make([]byte, 4)
			rand.Read(b)
			off = new(big.Int).SetUint64(uint64(b[0]) | uint64(b[1])<<8 | uint64(b[2])<<16 | uint64(b[3])<<24)
		}
		copy(seeds[i*32+32-len(off.Bytes()):(i+1)*32], off.Bytes())
	}

	s, err := gpuSearchInit(target, seeds, nWalks, 0)
	if err != nil {
		b.Fatal(err)
	}
	defer s.free()

	keysPerRound := gpuSearchKeysPerRound()
	rounds := uint64(50)
	keysPerBatch := uint64(nWalks) * rounds * uint64(keysPerRound)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _, err := s.run(rounds)
		if err != nil {
			b.Fatal(err)
		}
	}
	elapsed := float64(b.Elapsed().Nanoseconds()) / 1e9
	throughput := float64(keysPerBatch) * float64(b.N) / elapsed / 1e6
	b.ReportMetric(throughput, "Mkeys/s")
}
