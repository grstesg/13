package main

import (
	"encoding/hex"
	"math/big"
	"testing"
)

// TestGeneratorHash160 anchors the CPU reference used to validate the GPU:
// the compressed public key of private key 1 is the secp256k1 generator,
// whose hash160 is a well-known constant.
func TestGeneratorHash160(t *testing.T) {
	got, err := privateKeyToHash160(padPrivateKey(big.NewInt(1).Bytes(), 32))
	if err != nil {
		t.Fatal(err)
	}
	const want = "751e76e8199196d454941c45d1b3a323f1433bd6"
	if hex.EncodeToString(got) != want {
		t.Fatalf("hash160 of generator: got %x want %s", got, want)
	}
}
