// secp256k1 + hash160 on the GPU.
//
// Field elements are 256-bit values held as four little-endian 64-bit limbs
// (v[0] is least significant), kept fully reduced in [0, p) after every op.
// EC points are Jacobian (X, Y, Z); Z == 0 denotes the point at infinity.
//
// Correctness is validated against the btcec CPU reference in Go (gpu_test.go);
// any silent arithmetic bug shows up there, not as a crash.

#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

#include "secp256k1_gpu.h"

typedef unsigned __int128 u128;

// ---------------------------------------------------------------------------
// Field arithmetic mod p = 2^256 - 2^32 - 977
// ---------------------------------------------------------------------------

struct fe {
    uint64_t v[4];
};

// p and the reduction constant c, where 2^256 ≡ c (mod p), c = 2^32 + 977.
__device__ __constant__ uint64_t P[4] = {
    0xFFFFFFFEFFFFFC2FULL, 0xFFFFFFFFFFFFFFFFULL,
    0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL};
__device__ __constant__ uint64_t C_RED = 0x1000003D1ULL;

__device__ __forceinline__ void fe_set_zero(fe *r) {
    r->v[0] = r->v[1] = r->v[2] = r->v[3] = 0;
}
__device__ __forceinline__ void fe_set_u64(fe *r, uint64_t x) {
    r->v[0] = x; r->v[1] = r->v[2] = r->v[3] = 0;
}
__device__ __forceinline__ void fe_copy(fe *r, const fe *a) {
    r->v[0] = a->v[0]; r->v[1] = a->v[1]; r->v[2] = a->v[2]; r->v[3] = a->v[3];
}
__device__ __forceinline__ bool fe_is_zero(const fe *a) {
    return (a->v[0] | a->v[1] | a->v[2] | a->v[3]) == 0;
}
__device__ __forceinline__ bool fe_eq(const fe *a, const fe *b) {
    return a->v[0] == b->v[0] && a->v[1] == b->v[1] &&
           a->v[2] == b->v[2] && a->v[3] == b->v[3];
}

// Returns true if a >= p.
__device__ __forceinline__ bool fe_ge_p(const fe *a) {
    if (a->v[3] != P[3]) return a->v[3] > P[3];
    if (a->v[2] != P[2]) return a->v[2] > P[2];
    if (a->v[1] != P[1]) return a->v[1] > P[1];
    return a->v[0] >= P[0];
}

// r -= p (caller guarantees r >= p).
__device__ __forceinline__ void fe_sub_p(fe *r) {
    u128 t;
    uint64_t borrow = 0;
#pragma unroll
    for (int i = 0; i < 4; i++) {
        t = (u128)r->v[i] - P[i] - borrow;
        r->v[i] = (uint64_t)t;
        borrow = (uint64_t)(t >> 64) & 1;
    }
}

__device__ void fe_add(const fe *a, const fe *b, fe *r) {
    u128 t = 0;
#pragma unroll
    for (int i = 0; i < 4; i++) {
        t += (u128)a->v[i] + b->v[i];
        r->v[i] = (uint64_t)t;
        t >>= 64;
    }
    // a,b < p so a+b < 2p < 2^257: at most one extra subtraction needed.
    if ((uint64_t)t) fe_sub_p(r);
    else if (fe_ge_p(r)) fe_sub_p(r);
}

__device__ void fe_sub(const fe *a, const fe *b, fe *r) {
    u128 t;
    uint64_t borrow = 0;
#pragma unroll
    for (int i = 0; i < 4; i++) {
        t = (u128)a->v[i] - b->v[i] - borrow;
        r->v[i] = (uint64_t)t;
        borrow = (uint64_t)(t >> 64) & 1;
    }
    if (borrow) {  // result was negative: add p back.
        u128 c = 0;
#pragma unroll
        for (int i = 0; i < 4; i++) {
            c += (u128)r->v[i] + P[i];
            r->v[i] = (uint64_t)c;
            c >>= 64;
        }
    }
}

// 256x256 -> 512-bit schoolbook product (t little-endian, 8 limbs).
__device__ void mul_wide(const uint64_t a[4], const uint64_t b[4], uint64_t t[8]) {
#pragma unroll
    for (int i = 0; i < 8; i++) t[i] = 0;
#pragma unroll
    for (int i = 0; i < 4; i++) {
        uint64_t carry = 0;
#pragma unroll
        for (int j = 0; j < 4; j++) {
            u128 cur = (u128)a[i] * b[j] + t[i + j] + carry;
            t[i + j] = (uint64_t)cur;
            carry = (uint64_t)(cur >> 64);
        }
        t[i + 4] = carry;
    }
}

// Reduces a 512-bit value (8 limbs) mod p into r.
__device__ void fe_reduce_wide(const uint64_t t[8], fe *r) {
    // value = lo + hi * 2^256 ≡ lo + hi * c (mod p), with c < 2^33.
    const uint64_t c = C_RED;

    // m = hi * c  (4 limbs + a small carry m4).
    uint64_t m[4];
    uint64_t carry = 0;
#pragma unroll
    for (int i = 0; i < 4; i++) {
        u128 cur = (u128)t[i + 4] * c + carry;
        m[i] = (uint64_t)cur;
        carry = (uint64_t)(cur >> 64);
    }
    uint64_t m4 = carry;  // < 2^33

    // r = lo + m
    u128 acc = 0;
#pragma unroll
    for (int i = 0; i < 4; i++) {
        acc += (u128)t[i] + m[i];
        r->v[i] = (uint64_t)acc;
        acc >>= 64;
    }
    uint64_t of = m4 + (uint64_t)acc;  // overflow beyond 2^256, < 2^34

    // Fold the overflow back in: each iteration adds of*c (< 2^67); converges.
    while (of) {
        u128 prod = (u128)of * c;
        uint64_t add0 = (uint64_t)prod;
        uint64_t add1 = (uint64_t)(prod >> 64);
        u128 a0 = (u128)r->v[0] + add0;
        r->v[0] = (uint64_t)a0;
        uint64_t cr = (uint64_t)(a0 >> 64);
        u128 a1 = (u128)r->v[1] + add1 + cr;
        r->v[1] = (uint64_t)a1;
        cr = (uint64_t)(a1 >> 64);
        u128 a2 = (u128)r->v[2] + cr;
        r->v[2] = (uint64_t)a2;
        cr = (uint64_t)(a2 >> 64);
        u128 a3 = (u128)r->v[3] + cr;
        r->v[3] = (uint64_t)a3;
        of = (uint64_t)(a3 >> 64);
    }
    if (fe_ge_p(r)) fe_sub_p(r);
}

__device__ void fe_mul(const fe *a, const fe *b, fe *r) {
    uint64_t t[8];
    mul_wide(a->v, b->v, t);
    fe_reduce_wide(t, r);
}

// A dedicated Comba squaring (10 vs 16 limb muls) was tried here but measured
// slightly slower on this GPU — its data-dependent carry propagation hurt more
// than the saved multiplies helped — so squaring just reuses the multiply.
__device__ __forceinline__ void fe_sqr(const fe *a, fe *r) { fe_mul(a, a, r); }

// r = a^(2^n) — n repeated squarings (in place; aliasing r==a is safe).
__device__ __forceinline__ void fe_sqr_n(fe *r, const fe *a, int n) {
    fe_sqr(a, r);
    for (int i = 1; i < n; i++) fe_sqr(r, r);
}

// Modular inverse a^(p-2) via the libsecp256k1 addition chain: ~255 squarings
// but only ~15 multiplications (vs ~255 for naive square-and-multiply). p-2's
// bit pattern is blocks of ones of length {1, 2, 22, 223}.
__device__ void fe_inv(const fe *a, fe *r) {
    fe x2, x3, x6, x9, x11, x22, x44, x88, x176, x220, x223, t1;

    fe_sqr(a, &x2);   fe_mul(&x2, a, &x2);    // a^(2^2-1)
    fe_sqr(&x2, &x3); fe_mul(&x3, a, &x3);    // a^(2^3-1)

    fe_sqr_n(&x6, &x3, 3);   fe_mul(&x6, &x3, &x6);     // a^(2^6-1)
    fe_sqr_n(&x9, &x6, 3);   fe_mul(&x9, &x3, &x9);     // a^(2^9-1)
    fe_sqr_n(&x11, &x9, 2);  fe_mul(&x11, &x2, &x11);   // a^(2^11-1)
    fe_sqr_n(&x22, &x11, 11);fe_mul(&x22, &x11, &x22);  // a^(2^22-1)
    fe_sqr_n(&x44, &x22, 22);fe_mul(&x44, &x22, &x44);  // a^(2^44-1)
    fe_sqr_n(&x88, &x44, 44);fe_mul(&x88, &x44, &x88);  // a^(2^88-1)
    fe_sqr_n(&x176, &x88, 88);fe_mul(&x176, &x88, &x176);// a^(2^176-1)
    fe_sqr_n(&x220, &x176, 44);fe_mul(&x220, &x44, &x220);// a^(2^220-1)
    fe_sqr_n(&x223, &x220, 3); fe_mul(&x223, &x3, &x223);// a^(2^223-1)

    fe_sqr_n(&t1, &x223, 23); fe_mul(&t1, &x22, &t1);
    fe_sqr_n(&t1, &t1, 5);    fe_mul(&t1, a, &t1);
    fe_sqr_n(&t1, &t1, 3);    fe_mul(&t1, &x2, &t1);
    fe_sqr_n(&t1, &t1, 2);    fe_mul(&t1, a, r);
}

// ---------------------------------------------------------------------------
// EC arithmetic (Jacobian coordinates, curve a = 0)
// ---------------------------------------------------------------------------

struct ECPoint {
    fe X, Y, Z;
};

// Affine point (x, y). The search walks lanes in affine coordinates so the one
// batched inversion per step does double duty: it both performs the +G addition
// and yields the affine x used for hashing — no separate Jacobian->affine pass.
struct AffinePoint {
    fe x, y;
};

// Generator G (affine).
__device__ __constant__ uint64_t GX[4] = {
    0x59F2815B16F81798ULL, 0x029BFCDB2DCE28D9ULL,
    0x55A06295CE870B07ULL, 0x79BE667EF9DCBBACULL};
__device__ __constant__ uint64_t GY[4] = {
    0x9C47D08FFB10D4B8ULL, 0xFD17B448A6855419ULL,
    0x5DA4FBFC0E1108A8ULL, 0x483ADA7726A3C465ULL};

__device__ __forceinline__ void fe_mul2(const fe *a, fe *r) { fe_add(a, a, r); }
__device__ __forceinline__ void fe_mul3(const fe *a, fe *r) {
    fe t; fe_add(a, a, &t); fe_add(&t, a, r);
}

// Point doubling (dbl-2009-l).
__device__ void point_double(const ECPoint *p, ECPoint *r) {
    if (fe_is_zero(&p->Z) || fe_is_zero(&p->Y)) {
        fe_set_zero(&r->X); fe_set_u64(&r->Y, 1); fe_set_zero(&r->Z);
        return;
    }
    fe A, B, Cc, D, E, F, t, t2;
    fe_sqr(&p->X, &A);          // A = X^2
    fe_sqr(&p->Y, &B);          // B = Y^2
    fe_sqr(&B, &Cc);            // C = B^2
    fe_add(&p->X, &B, &t);      // X+B
    fe_sqr(&t, &t);             // (X+B)^2
    fe_sub(&t, &A, &t);         // - A
    fe_sub(&t, &Cc, &t);        // - C
    fe_mul2(&t, &D);            // D = 2*((X+B)^2 - A - C)
    fe_mul3(&A, &E);            // E = 3*A
    fe_sqr(&E, &F);             // F = E^2
    fe_mul2(&D, &t);            // 2D
    fe_sub(&F, &t, &r->X);      // X3 = F - 2D
    fe_sub(&D, &r->X, &t);      // D - X3
    fe_mul(&E, &t, &t);         // E*(D - X3)
    fe_mul2(&Cc, &t2); fe_mul2(&t2, &t2); fe_mul2(&t2, &t2);  // 8C
    fe_sub(&t, &t2, &r->Y);     // Y3 = E*(D-X3) - 8C
    fe_mul(&p->Y, &p->Z, &t);   // Y*Z
    fe_mul2(&t, &r->Z);         // Z3 = 2*Y*Z
}

// Mixed addition: Jacobian p + affine (qx, qy)  (madd-2007-bl).
__device__ void point_add_affine(const ECPoint *p, const fe *qx, const fe *qy,
                                 ECPoint *r) {
    if (fe_is_zero(&p->Z)) {  // p is infinity -> result = Q.
        fe_copy(&r->X, qx);
        fe_copy(&r->Y, qy);
        fe_set_u64(&r->Z, 1);
        return;
    }
    fe Z1Z1, U2, S2, H, HH, I, J, rr, V, t, t2;
    fe_sqr(&p->Z, &Z1Z1);       // Z1Z1 = Z1^2
    fe_mul(qx, &Z1Z1, &U2);     // U2 = X2*Z1Z1
    fe_mul(&p->Z, &Z1Z1, &t);   // Z1*Z1Z1
    fe_mul(qy, &t, &S2);        // S2 = Y2*Z1^3
    fe_sub(&U2, &p->X, &H);     // H = U2 - X1
    if (fe_is_zero(&H)) {
        fe_sub(&S2, &p->Y, &t);
        if (fe_is_zero(&t)) {   // P == Q -> double.
            point_double(p, r);
            return;
        }
        // P == -Q -> infinity.
        fe_set_zero(&r->X); fe_set_u64(&r->Y, 1); fe_set_zero(&r->Z);
        return;
    }
    fe_sqr(&H, &HH);            // HH = H^2
    fe_mul2(&HH, &I); fe_mul2(&I, &I);  // I = 4*HH
    fe_mul(&H, &I, &J);        // J = H*I
    fe_sub(&S2, &p->Y, &t);    // S2 - Y1
    fe_mul2(&t, &rr);          // r = 2*(S2 - Y1)
    fe_mul(&p->X, &I, &V);     // V = X1*I
    fe_sqr(&rr, &t);           // r^2
    fe_sub(&t, &J, &t);        // - J
    fe_mul2(&V, &t2);          // 2V
    fe_sub(&t, &t2, &r->X);    // X3 = r^2 - J - 2V
    fe_sub(&V, &r->X, &t);     // V - X3
    fe_mul(&rr, &t, &t);       // r*(V - X3)
    fe_mul(&p->Y, &J, &t2);    // Y1*J
    fe_mul2(&t2, &t2);         // 2*Y1*J
    fe_sub(&t, &t2, &r->Y);    // Y3
    fe_add(&p->Z, &H, &t);     // Z1 + H
    fe_sqr(&t, &t);            // (Z1+H)^2
    fe_sub(&t, &Z1Z1, &t);     // - Z1Z1
    fe_sub(&t, &HH, &r->Z);    // Z3 = (Z1+H)^2 - Z1Z1 - HH
}

// R = k * G via double-and-add (k little-endian limbs). Used only for seeding.
__device__ void scalar_mul_base(const uint64_t k[4], ECPoint *r) {
    fe gx, gy;
#pragma unroll
    for (int i = 0; i < 4; i++) { gx.v[i] = GX[i]; gy.v[i] = GY[i]; }
    fe_set_zero(&r->X); fe_set_u64(&r->Y, 1); fe_set_zero(&r->Z);  // infinity
    for (int limb = 3; limb >= 0; limb--) {
        uint64_t e = k[limb];
        for (int bit = 63; bit >= 0; bit--) {
            ECPoint t;
            point_double(r, &t);
            *r = t;
            if ((e >> bit) & 1ULL) {
                ECPoint t2;
                point_add_affine(r, &gx, &gy, &t2);
                *r = t2;
            }
        }
    }
}

// ---------------------------------------------------------------------------
// SHA-256 (single 512-bit block)
// ---------------------------------------------------------------------------

__device__ __constant__ uint32_t SHA_K[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
    0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
    0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
    0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
    0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
    0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};

// Rotates as a single funnel-shift (SHF) instruction rather than the
// shift/shift/or idiom.
__device__ __forceinline__ uint32_t rotr32(uint32_t x, int n) {
    return __funnelshift_r(x, x, n);
}
__device__ __forceinline__ uint32_t rotl32(uint32_t x, int n) {
    return __funnelshift_l(x, x, n);
}

#define SIG0(x) (rotr32(x, 7) ^ rotr32(x, 18) ^ ((x) >> 3))
#define SIG1(x) (rotr32(x, 17) ^ rotr32(x, 19) ^ ((x) >> 10))
#define EP0(x)  (rotr32(x, 2) ^ rotr32(x, 13) ^ rotr32(x, 22))
#define EP1(x)  (rotr32(x, 6) ^ rotr32(x, 11) ^ rotr32(x, 25))
#define CHF(x, y, z)  (((x) & (y)) ^ (~(x) & (z)))
#define MAJF(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))

// SHA-256 of the 33-byte compressed public key (0x02|0x03 || x), which is a
// single block. Specialized two ways over a generic block hash:
//
//   * The message tail is constant (0x80 pad, zeros, bit length 0x108), so
//     schedule words w[9..15] are literals and every term that multiplies
//     through them folds away at compile time.
//   * The schedule is a rolling 16-word window instead of a materialized
//     w[64], which is what let the generic version spill: 64 live words could
//     never fit the register budget.
//
// SHA_K stays in __constant__ on purpose — with a literal index it becomes an
// inline constant-bank operand, so it costs no instruction.
__device__ __forceinline__ void sha256_pubkey(const fe *px, bool oddY, uint32_t st[8]) {
    // x as eight big-endian 32-bit words, X0 most significant.
    uint32_t X0 = (uint32_t)(px->v[3] >> 32), X1 = (uint32_t)px->v[3];
    uint32_t X2 = (uint32_t)(px->v[2] >> 32), X3 = (uint32_t)px->v[2];
    uint32_t X4 = (uint32_t)(px->v[1] >> 32), X5 = (uint32_t)px->v[1];
    uint32_t X6 = (uint32_t)(px->v[0] >> 32), X7 = (uint32_t)px->v[0];

    // The 33-byte message is byte-offset by one, so each word straddles two of
    // the X words: one funnel shift each.
    uint32_t w[16];
    w[0] = ((oddY ? 0x03u : 0x02u) << 24) | (X0 >> 8);
    w[1] = (X0 << 24) | (X1 >> 8);
    w[2] = (X1 << 24) | (X2 >> 8);
    w[3] = (X2 << 24) | (X3 >> 8);
    w[4] = (X3 << 24) | (X4 >> 8);
    w[5] = (X4 << 24) | (X5 >> 8);
    w[6] = (X5 << 24) | (X6 >> 8);
    w[7] = (X6 << 24) | (X7 >> 8);
    w[8] = (X7 << 24) | 0x00800000u;   // last x byte, then the padding bit
    w[9] = 0; w[10] = 0; w[11] = 0; w[12] = 0; w[13] = 0; w[14] = 0;
    w[15] = 0x00000108u;               // 33 bytes = 264 bits

    uint32_t a = 0x6a09e667, b = 0xbb67ae85, c = 0x3c6ef372, d = 0xa54ff53a;
    uint32_t e = 0x510e527f, f = 0x9b05688c, g = 0x1f83d9ab, h = 0x5be0cd19;

#pragma unroll
    for (int i = 0; i < 64; i++) {
        // Slot i&15 holds w[i-16]; the other three taps are the same window
        // rotated. Updating in place keeps all 16 words live in registers.
        uint32_t wi = (i < 16)
            ? w[i]
            : (w[i & 15] += SIG0(w[(i + 1) & 15]) + w[(i + 9) & 15] +
                            SIG1(w[(i + 14) & 15]));
        uint32_t t1 = h + EP1(e) + CHF(e, f, g) + SHA_K[i] + wi;
        uint32_t t2 = EP0(a) + MAJF(a, b, c);
        h = g; g = f; f = e; e = d + t1;
        d = c; c = b; b = a; a = t1 + t2;
    }

    st[0] = 0x6a09e667 + a; st[1] = 0xbb67ae85 + b;
    st[2] = 0x3c6ef372 + c; st[3] = 0xa54ff53a + d;
    st[4] = 0x510e527f + e; st[5] = 0x9b05688c + f;
    st[6] = 0x1f83d9ab + g; st[7] = 0x5be0cd19 + h;
}

// ---------------------------------------------------------------------------
// RIPEMD-160 (single 512-bit block)
// ---------------------------------------------------------------------------

__device__ __forceinline__ uint32_t rmd_f(int round, uint32_t x, uint32_t y, uint32_t z) {
    switch (round) {
        case 0: return x ^ y ^ z;
        case 1: return (x & y) | (~x & z);
        case 2: return (x | ~y) ^ z;
        case 3: return (x & z) | (y & ~z);
        default: return x ^ (y | ~z);
    }
}

// RIPEMD-160 of a SHA-256 digest — the second half of hash160. The input is
// always 32 bytes, so the block is the digest plus constant padding and X[9..13]
// and X[15] are literal zeros.
//
// The schedule/shift tables are deliberately *function-local* rather than
// __constant__: they index X and supply shift amounts, so they have to become
// compile-time literals. Under full unrolling they do, which keeps X[16] in
// registers. As __constant__ arrays they stayed runtime values, forcing X into
// local memory and a constant load on every one of the 160 round-halves.
__device__ __forceinline__ void ripemd160_sha(const uint32_t sh[8], uint32_t out[5]) {
    const int RL[80] = {
        0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,
        7,4,13,1,10,6,15,3,12,0,9,5,2,14,11,8,
        3,10,14,4,9,15,8,1,2,7,0,6,13,11,5,12,
        1,9,11,10,0,8,12,4,13,3,7,15,14,5,6,2,
        4,0,5,9,7,12,2,10,14,1,3,8,11,6,15,13};
    const int RR[80] = {
        5,14,7,0,9,2,11,4,13,6,15,8,1,10,3,12,
        6,11,3,7,0,13,5,10,14,15,8,12,4,9,1,2,
        15,5,1,3,7,14,6,9,11,8,12,2,10,0,4,13,
        8,6,4,1,3,11,15,0,5,12,2,13,9,7,10,14,
        12,15,10,4,1,5,8,7,6,2,13,14,0,3,9,11};
    const int SL[80] = {
        11,14,15,12,5,8,7,9,11,13,14,15,6,7,9,8,
        7,6,8,13,11,9,7,15,7,12,15,9,11,7,13,12,
        11,13,6,7,14,9,13,15,14,8,13,6,5,12,7,5,
        11,12,14,15,14,15,9,8,9,14,5,6,8,6,5,12,
        9,15,5,11,6,8,13,12,5,12,13,14,11,8,5,6};
    const int SR[80] = {
        8,9,9,11,13,15,15,5,7,7,8,11,14,14,12,6,
        9,13,15,7,12,8,9,11,7,7,12,7,6,15,13,11,
        9,7,15,11,8,6,6,14,12,13,5,14,13,13,7,5,
        15,5,8,11,14,14,6,14,6,9,12,9,12,5,15,8,
        8,5,12,9,12,5,14,6,8,13,6,5,15,13,11,11};
    const uint32_t KL[5] = {0x00000000, 0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xA953FD4E};
    const uint32_t KR[5] = {0x50A28BE6, 0x5C4DD124, 0x6D703EF3, 0x7A6D76E9, 0x00000000};

    // RIPEMD reads little-endian words; the SHA state is big-endian.
    uint32_t X[16];
#pragma unroll
    for (int i = 0; i < 8; i++) X[i] = __byte_perm(sh[i], 0, 0x0123);
    X[8] = 0x00000080u;   // padding bit
    X[9] = 0; X[10] = 0; X[11] = 0; X[12] = 0; X[13] = 0;
    X[14] = 0x00000100u;  // 32 bytes = 256 bits
    X[15] = 0;

    uint32_t al = 0x67452301, bl = 0xEFCDAB89, cl = 0x98BADCFE,
             dl = 0x10325476, el = 0xC3D2E1F0;
    uint32_t ar = al, br = bl, cr = cl, dr = dl, er = el;

#pragma unroll
    for (int j = 0; j < 80; j++) {
        const int round = j / 16;
        uint32_t t = rotl32(al + rmd_f(round, bl, cl, dl) + X[RL[j]] + KL[round], SL[j]) + el;
        al = el; el = dl; dl = rotl32(cl, 10); cl = bl; bl = t;

        t = rotl32(ar + rmd_f(4 - round, br, cr, dr) + X[RR[j]] + KR[round], SR[j]) + er;
        ar = er; er = dr; dr = rotl32(cr, 10); cr = br; br = t;
    }

    out[0] = 0xEFCDAB89 + cl + dr;
    out[1] = 0x98BADCFE + dl + er;
    out[2] = 0x10325476 + el + ar;
    out[3] = 0xC3D2E1F0 + al + br;
    out[4] = 0x67452301 + bl + cr;
}

// hash160 = RIPEMD160(SHA256(0x02|0x03 || x)) for affine x and y-parity,
// returned as five little-endian words so the search can compare without ever
// materializing bytes.
__device__ __forceinline__ void hash160_from_affine(const fe *x, bool oddY, uint32_t out[5]) {
    uint32_t sh[8];
    sha256_pubkey(x, oddY, sh);
    ripemd160_sha(sh, out);
}

// Converts a Jacobian point with precomputed 1/Z into affine x and y-parity.
__device__ void affine_from_jacobian(const ECPoint *p, const fe *zinv,
                                     fe *x, bool *oddY) {
    fe zinv2, zinv3, y;
    fe_sqr(zinv, &zinv2);
    fe_mul(&p->X, &zinv2, x);
    fe_mul(&zinv2, zinv, &zinv3);
    fe_mul(&p->Y, &zinv3, &y);
    *oddY = (y.v[0] & 1ULL) != 0;
}

// ---------------------------------------------------------------------------
// Kernels
// ---------------------------------------------------------------------------

// One thread per key: hash160 of n big-endian private keys (test helper).
__global__ void k_hash160_batch(const uint8_t *keys, int n, uint8_t *out20) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= n) return;
    const uint8_t *kb = keys + idx * 32;
    uint64_t k[4];
#pragma unroll
    for (int i = 0; i < 4; i++) {  // big-endian bytes -> little-endian limbs
        uint64_t limb = 0;
#pragma unroll
        for (int b = 0; b < 8; b++) limb = (limb << 8) | kb[(3 - i) * 8 + b];
        k[i] = limb;
    }
    ECPoint p;
    scalar_mul_base(k, &p);
    fe zinv, x;
    bool oddY;
    fe_inv(&p.Z, &zinv);
    affine_from_jacobian(&p, &zinv, &x, &oddY);
    uint32_t h[5];
    hash160_from_affine(&x, oddY, h);
    uint8_t *o = out20 + idx * 20;
#pragma unroll
    for (int i = 0; i < 5; i++) {
        o[i * 4]     = (uint8_t)(h[i]);
        o[i * 4 + 1] = (uint8_t)(h[i] >> 8);
        o[i * 4 + 2] = (uint8_t)(h[i] >> 16);
        o[i * 4 + 3] = (uint8_t)(h[i] >> 24);
    }
}

// Seeds one affine point per lane from its starting scalar. The per-lane field
// inversion here is a one-time cost paid only at startup (not in the hot loop).
__global__ void k_seed(const uint64_t *seeds, AffinePoint *pts, int n_lanes) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= n_lanes) return;
    ECPoint p;
    scalar_mul_base(seeds + idx * 4, &p);
    fe zinv, zinv2, zinv3;
    fe_inv(&p.Z, &zinv);
    fe_sqr(&zinv, &zinv2);
    fe_mul(&zinv2, &zinv, &zinv3);
    fe_mul(&p.X, &zinv2, &pts[idx].x);  // x = X / Z^2
    fe_mul(&p.Y, &zinv3, &pts[idx].y);  // y = Y / Z^3
}

// Tunables, overridable with -D so they can be swept without editing source.
//
// GRP_HALF sets the group size: each round a walk covers the GRP_KEYS keys
// centred on its current point, using ONE field inversion. Bigger groups
// amortize the inversion further but need a larger per-thread prefix array.
// MIN_BLOCKS_PER_SM is the occupancy target handed to __launch_bounds__, which
// is what sets the per-thread register budget.
#ifndef GRP_HALF
#define GRP_HALF 256
#endif
#ifndef THREADS_PER_BLOCK
#define THREADS_PER_BLOCK 128
#endif
#ifndef MIN_BLOCKS_PER_SM
#define MIN_BLOCKS_PER_SM 6
#endif

// Keys covered per walk per round: the centre, plus a +/- pair per table entry.
#define GRP_KEYS (2 * GRP_HALF + 1)

// Search state shared with the host via device globals. The match is recorded
// as (walk, signed offset from that walk's seed) and turned back into a scalar
// on the host, which already holds the seeds -- no 256-bit arithmetic here.
__device__ uint32_t d_found_flag;
__device__ uint32_t d_found_walk;
__device__ long long d_found_off;

// The target hash160 as five little-endian words.
__device__ __constant__ uint32_t c_target[5];

// r = -a (mod p).
__device__ __forceinline__ void fe_neg(const fe *a, fe *r) {
    if (fe_is_zero(a)) { fe_set_zero(r); return; }
    u128 t;
    uint64_t borrow = 0;
#pragma unroll
    for (int i = 0; i < 4; i++) {
        t = (u128)P[i] - a->v[i] - borrow;
        r->v[i] = (uint64_t)t;
        borrow = (uint64_t)(t >> 64) & 1;
    }
}

__device__ __forceinline__ void load_fe(const fe *src, fe *dst) {
#pragma unroll
    for (int i = 0; i < 4; i++) dst->v[i] = __ldg(&src->v[i]);
}

// R = P + Q in affine coordinates, given inv = 1/(Px - Qx) from the batch.
// The slope is lambda = (Py - Qy) * inv; three multiplies, no inversion.
__device__ __forceinline__ void add_with_inv(const fe *px, const fe *py,
                                             const fe *qx, const fe *qy,
                                             const fe *inv, fe *rx, fe *ry) {
    fe dy, lam, t;
    fe_sub(py, qy, &dy);
    fe_mul(&dy, inv, &lam);
    fe_sqr(&lam, &t);
    fe_sub(&t, px, &t);
    fe_sub(&t, qx, rx);          // x3 = lambda^2 - Px - Qx
    fe_sub(px, rx, &t);
    fe_mul(&lam, &t, ry);
    fe_sub(ry, py, ry);          // y3 = lambda*(Px - x3) - Py
}

// Hashes one candidate point and claims the match if it is the target.
__device__ __forceinline__ void check_point(const fe *x, const fe *y,
                                            int walk, long long off) {
    uint32_t h[5];
#ifdef BENCH_NO_HASH
    // Ablation: skip hashing but keep a data-dependent compare so the EC work
    // producing this point cannot be optimized away.
#pragma unroll
    for (int i = 0; i < 5; i++) h[i] = (uint32_t)(x->v[i & 3] >> 11);
#else
    hash160_from_affine(x, (y->v[0] & 1ULL) != 0, h);
#endif
    if (h[0] == c_target[0] && h[1] == c_target[1] && h[2] == c_target[2] &&
        h[3] == c_target[3] && h[4] == c_target[4]) {
        if (atomicCAS(&d_found_flag, 0u, 1u) == 0u) {
            d_found_walk = (uint32_t)walk;
            d_found_off = off;
        }
    }
}

// One thread per walk. Each round covers a contiguous block of GRP_KEYS keys
// centred on the walk's current point P, then jumps the centre forward by
// GRP_KEYS so successive rounds tile the key space without gaps or overlap.
//
// The whole round costs a single field inversion. Two things make that pay:
//
//   * Montgomery's trick batches the GRP_HALF+1 denominators (Px - x(iG)) into
//     one inversion, so its ~270 multiplies amortize across the group.
//   * The +/- symmetry halves how many denominators are needed at all. -Q has
//     the same x as Q, so P+iG and P-iG share the denominator Px - x(iG): one
//     inverse yields two keys. That is the difference between ~14.4 and ~5.5
//     field multiplies per key.
//
// The table gtab[i] holds (i+1)*G for i < GRP_HALF, with the jump point
// GRP_KEYS*G in the last slot. Every thread reads the same entry at the same
// time, so these loads broadcast out of cache.
__global__ void __launch_bounds__(THREADS_PER_BLOCK, MIN_BLOCKS_PER_SM)
k_step(AffinePoint *pts, const AffinePoint *gtab, int n_walks,
       unsigned long long rounds, unsigned long long round_base) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= n_walks) return;

    fe px, py;
    fe_copy(&px, &pts[tid].x);
    fe_copy(&py, &pts[tid].y);

    // Running products of the batch inversion. Only the prefixes are stored:
    // the denominators themselves are recomputed on the backward pass from the
    // (round-invariant) centre and the table, which is cheaper than keeping a
    // second array of this size live.
    fe prefix[GRP_HALF + 1];

    for (unsigned long long r = 0; r < rounds; r++) {
        if (d_found_flag) break;
        long long centre = (long long)((round_base + r) * (unsigned long long)GRP_KEYS);

        check_point(&px, &py, tid, centre);

        // Forward pass: acc becomes the product of every denominator.
        fe acc;
        fe_set_u64(&acc, 1);
#pragma unroll 1
        for (int i = 0; i <= GRP_HALF; i++) {
            fe gx, d;
            load_fe(&gtab[i].x, &gx);
            fe_sub(&px, &gx, &d);
            fe_copy(&prefix[i], &acc);
            // d == 0 means the walk landed exactly on +-(i+1)G, which cannot
            // happen for puzzle-sized keys; guard anyway so one lane can never
            // zero the whole batch product.
            if (!fe_is_zero(&d)) {
                fe t;
                fe_mul(&acc, &d, &t);
                fe_copy(&acc, &t);
            }
        }
        fe accinv;
        fe_inv(&acc, &accinv);

        // Backward pass: peel the denominators off in reverse, recovering each
        // individual inverse, and spend it on a +/- pair of point additions.
        // The jump entry is peeled first; the new centre is held aside until
        // the round finishes, since every addition needs the old one.
        fe nx, ny;
        fe_copy(&nx, &px);
        fe_copy(&ny, &py);
        {
            fe gx, gy, d;
            load_fe(&gtab[GRP_HALF].x, &gx);
            load_fe(&gtab[GRP_HALF].y, &gy);
            fe_sub(&px, &gx, &d);
            if (!fe_is_zero(&d)) {
                fe inv, t;
                fe_mul(&accinv, &prefix[GRP_HALF], &inv);
                fe_mul(&accinv, &d, &t);
                fe_copy(&accinv, &t);
                add_with_inv(&px, &py, &gx, &gy, &inv, &nx, &ny);
            }
        }
#pragma unroll 1
        for (int i = GRP_HALF - 1; i >= 0; i--) {
            fe gx, gy, d;
            load_fe(&gtab[i].x, &gx);
            load_fe(&gtab[i].y, &gy);
            fe_sub(&px, &gx, &d);
            if (fe_is_zero(&d)) continue;

            fe inv, t;
            fe_mul(&accinv, &prefix[i], &inv);   // inv = 1 / (Px - x(iG))
            fe_mul(&accinv, &d, &t);             // peel it off the product
            fe_copy(&accinv, &t);

            fe ax, ay;
            add_with_inv(&px, &py, &gx, &gy, &inv, &ax, &ay);
            check_point(&ax, &ay, tid, centre + (i + 1));

            // -Q shares Q's x, so the same inverse serves the subtraction.
            fe ngy, sx, sy;
            fe_neg(&gy, &ngy);
            add_with_inv(&px, &py, &gx, &ngy, &inv, &sx, &sy);
            check_point(&sx, &sy, tid, centre - (i + 1));
        }

        fe_copy(&px, &nx);
        fe_copy(&py, &ny);
    }

    fe_copy(&pts[tid].x, &px);
    fe_copy(&pts[tid].y, &py);
}

// Builds the group table: gtab[i] = (i+1)*G for i < GRP_HALF, and the jump
// point GRP_KEYS*G in the last slot. One-time startup cost on a single thread.
__global__ void k_gtab(AffinePoint *gtab) {
    fe gx, gy;
#pragma unroll
    for (int i = 0; i < 4; i++) { gx.v[i] = GX[i]; gy.v[i] = GY[i]; }

    ECPoint acc;
    fe_copy(&acc.X, &gx);
    fe_copy(&acc.Y, &gy);
    fe_set_u64(&acc.Z, 1);

    for (int i = 0; i < GRP_HALF; i++) {
        fe zinv, zinv2, zinv3;
        fe_inv(&acc.Z, &zinv);
        fe_sqr(&zinv, &zinv2);
        fe_mul(&zinv2, &zinv, &zinv3);
        fe_mul(&acc.X, &zinv2, &gtab[i].x);
        fe_mul(&acc.Y, &zinv3, &gtab[i].y);
        if (i + 1 < GRP_HALF) {
            ECPoint t;
            point_add_affine(&acc, &gx, &gy, &t);   // acc += G
            acc = t;
        }
    }

    // Jump point: GRP_KEYS*G, reached by scalar multiplication.
    uint64_t k[4] = {(uint64_t)GRP_KEYS, 0, 0, 0};
    ECPoint j;
    scalar_mul_base(k, &j);
    fe zinv, zinv2, zinv3;
    fe_inv(&j.Z, &zinv);
    fe_sqr(&zinv, &zinv2);
    fe_mul(&zinv2, &zinv, &zinv3);
    fe_mul(&j.X, &zinv2, &gtab[GRP_HALF].x);
    fe_mul(&j.Y, &zinv3, &gtab[GRP_HALF].y);
}

// ---------------------------------------------------------------------------
// Host API
// ---------------------------------------------------------------------------

struct GpuSearchCtx {
    AffinePoint *d_pts;      // one affine centre per walk
    AffinePoint *d_gtab;     // GRP_HALF multiples of G, plus the jump point
    uint64_t *h_seeds;       // host copy, used to rebuild a matched key
    int n_walks;
    int device;              // CUDA device this context is bound to
    unsigned long long round_base;
    cudaStream_t stream;     // per-context stream so multi-GPU work can overlap
};

static void seeds_be_to_limbs(const uint8_t *seeds_be, int n_walks, uint64_t *out) {
    for (int i = 0; i < n_walks; i++) {
        const uint8_t *s = seeds_be + i * 32;
        for (int l = 0; l < 4; l++) {
            uint64_t limb = 0;
            for (int b = 0; b < 8; b++) limb = (limb << 8) | s[(3 - l) * 8 + b];
            out[i * 4 + l] = limb;
        }
    }
}

extern "C" int gpu_device_count(void) {
    int n = 0;
    cudaError_t e = cudaGetDeviceCount(&n);
    if (e != cudaSuccess) return -(int)e;
    return n;
}

extern "C" int gpu_device_name(int idx, char *buf, int buflen) {
    cudaDeviceProp prop;
    cudaError_t e = cudaGetDeviceProperties(&prop, idx);
    if (e != cudaSuccess) return -(int)e;
    snprintf(buf, buflen, "%s", prop.name);
    return 0;
}

extern "C" int gpu_search_walk_multiple(void) {
    return THREADS_PER_BLOCK;
}

extern "C" int gpu_search_keys_per_round(void) {
    return GRP_KEYS;
}

extern "C" int gpu_hash160_batch(const uint8_t *keys, int n, uint8_t *out20) {
    uint8_t *d_keys = nullptr, *d_out = nullptr;
    cudaError_t e;
    if ((e = cudaMalloc(&d_keys, (size_t)n * 32)) != cudaSuccess) return -(int)e;
    if ((e = cudaMalloc(&d_out, (size_t)n * 20)) != cudaSuccess) { cudaFree(d_keys); return -(int)e; }
    cudaMemcpy(d_keys, keys, (size_t)n * 32, cudaMemcpyHostToDevice);
    int blocks = (n + 255) / 256;
    k_hash160_batch<<<blocks, 256>>>(d_keys, n, d_out);
    e = cudaGetLastError();
    if (e != cudaSuccess) { cudaFree(d_keys); cudaFree(d_out); return -(int)e; }
    e = cudaDeviceSynchronize();
    if (e == cudaSuccess) cudaMemcpy(out20, d_out, (size_t)n * 20, cudaMemcpyDeviceToHost);
    cudaFree(d_keys);
    cudaFree(d_out);
    return e == cudaSuccess ? 0 : -(int)e;
}

// Mark a device buffer as persisting in L2. Best effort: failures are ignored
// so the search still works on old toolkits/drivers or when the buffer is too
// large for the available persistent L2 budget.
static void set_l2_persistent(void *base, size_t size, cudaStream_t stream) {
#if CUDART_VERSION >= 11000
    if (!base || !size) return;

    int device = 0;
    cudaGetDevice(&device);

    int supports = 0;
    cudaDeviceGetAttribute(&supports, cudaDevAttrMaxPersistingL2CacheSize, device);
    if (supports == 0) return;

    size_t max_size = 0;
    cudaDeviceGetLimit(&max_size, cudaLimitPersistingL2CacheSize);
    if (size > max_size) {
        cudaDeviceSetLimit(cudaLimitPersistingL2CacheSize, size);
        cudaGetLastError(); // ignore budget-exceeded errors
    }

    cudaStreamAttrValue attr;
    memset(&attr, 0, sizeof(attr));
    attr.accessPolicyWindow.base_ptr = base;
    attr.accessPolicyWindow.num_bytes = size;
    attr.accessPolicyWindow.hitRatio = 1.0;
    attr.accessPolicyWindow.hitProp = cudaAccessPropertyPersisting;
    attr.accessPolicyWindow.missProp = cudaAccessPropertyStreaming;
    cudaStreamSetAttribute(stream, cudaStreamAttributeAccessPolicyWindow, &attr);
    cudaGetLastError(); // clear any API error so it does not poison later calls
#endif
}

static void clear_l2_persistent(cudaStream_t stream) {
#if CUDART_VERSION >= 11000
    cudaStreamAttrValue attr;
    memset(&attr, 0, sizeof(attr));
    attr.accessPolicyWindow.base_ptr = nullptr;
    attr.accessPolicyWindow.num_bytes = 0;
    attr.accessPolicyWindow.hitRatio = 0.0;
    attr.accessPolicyWindow.hitProp = cudaAccessPropertyNormal;
    attr.accessPolicyWindow.missProp = cudaAccessPropertyNormal;
    cudaStreamSetAttribute(stream, cudaStreamAttributeAccessPolicyWindow, &attr);
    cudaGetLastError();
#endif
}

extern "C" GpuSearchCtx *gpu_search_init(const uint8_t *target20,
                                         const uint8_t *seeds_be, int n_walks,
                                         int device) {
    if (n_walks <= 0 || n_walks % gpu_search_walk_multiple() != 0) return nullptr;

    cudaError_t e = cudaSetDevice(device);
    if (e != cudaSuccess) return nullptr;

    GpuSearchCtx *ctx = new GpuSearchCtx();
    ctx->d_pts = nullptr;
    ctx->d_gtab = nullptr;
    ctx->n_walks = n_walks;
    ctx->device = device;
    ctx->round_base = 0;
    ctx->stream = 0;

    e = cudaStreamCreate(&ctx->stream);
    if (e != cudaSuccess) {
        delete ctx;
        return nullptr;
    }

    uint32_t target[5];
    for (int i = 0; i < 5; i++) {
        target[i] = (uint32_t)target20[i * 4] |
                    ((uint32_t)target20[i * 4 + 1] << 8) |
                    ((uint32_t)target20[i * 4 + 2] << 16) |
                    ((uint32_t)target20[i * 4 + 3] << 24);
    }
    cudaMemcpyToSymbolAsync(c_target, target, sizeof(target), 0,
                            cudaMemcpyHostToDevice, ctx->stream);

    ctx->h_seeds = (uint64_t *)malloc((size_t)n_walks * 4 * sizeof(uint64_t));
    seeds_be_to_limbs(seeds_be, n_walks, ctx->h_seeds);

    uint64_t *d_seeds = nullptr;
    bool ok = cudaMalloc(&ctx->d_pts, (size_t)n_walks * sizeof(AffinePoint)) == cudaSuccess &&
              cudaMalloc(&ctx->d_gtab, (size_t)(GRP_HALF + 1) * sizeof(AffinePoint)) == cudaSuccess &&
              cudaMalloc(&d_seeds, (size_t)n_walks * 4 * sizeof(uint64_t)) == cudaSuccess;
    if (!ok) {
        cudaStreamDestroy(ctx->stream);
        cudaFree(ctx->d_pts); cudaFree(ctx->d_gtab); cudaFree(d_seeds);
        free(ctx->h_seeds); delete ctx; return nullptr;
    }

    // Persist the group table and walk centres in L2. On most GPUs this avoids
    // re-fetching the shared gtab every round and keeps per-thread state hot.
    set_l2_persistent(ctx->d_gtab, (size_t)(GRP_HALF + 1) * sizeof(AffinePoint), ctx->stream);
    set_l2_persistent(ctx->d_pts, (size_t)n_walks * sizeof(AffinePoint), ctx->stream);

    cudaMemcpyAsync(d_seeds, ctx->h_seeds, (size_t)n_walks * 4 * sizeof(uint64_t),
                    cudaMemcpyHostToDevice, ctx->stream);

    uint32_t zero = 0;
    cudaMemcpyToSymbolAsync(d_found_flag, &zero, sizeof(zero), 0,
                            cudaMemcpyHostToDevice, ctx->stream);

    k_gtab<<<1, 1, 0, ctx->stream>>>(ctx->d_gtab);
    e = cudaGetLastError();
    if (e != cudaSuccess) {
        cudaStreamDestroy(ctx->stream);
        cudaFree(ctx->d_pts); cudaFree(ctx->d_gtab); cudaFree(d_seeds);
        free(ctx->h_seeds); delete ctx; return nullptr;
    }
    int blocks = (n_walks + 255) / 256;
    k_seed<<<blocks, 256, 0, ctx->stream>>>(d_seeds, ctx->d_pts, n_walks);
    e = cudaGetLastError();
    if (e != cudaSuccess) {
        cudaStreamDestroy(ctx->stream);
        cudaFree(ctx->d_pts); cudaFree(ctx->d_gtab); cudaFree(d_seeds);
        free(ctx->h_seeds); delete ctx; return nullptr;
    }
    e = cudaStreamSynchronize(ctx->stream);
    cudaFree(d_seeds);
    if (e != cudaSuccess) {
        cudaStreamDestroy(ctx->stream);
        cudaFree(ctx->d_pts); cudaFree(ctx->d_gtab);
        free(ctx->h_seeds); delete ctx; return nullptr;
    }
    return ctx;
}

extern "C" int gpu_search_run(GpuSearchCtx *ctx, unsigned long long rounds,
                              uint8_t found_key_be[32]) {
    cudaError_t e = cudaSetDevice(ctx->device);
    if (e != cudaSuccess) return -(int)e;

    int blocks = (ctx->n_walks + THREADS_PER_BLOCK - 1) / THREADS_PER_BLOCK;

    k_step<<<blocks, THREADS_PER_BLOCK, 0, ctx->stream>>>(ctx->d_pts, ctx->d_gtab,
                                                          ctx->n_walks, rounds,
                                                          ctx->round_base);
    e = cudaGetLastError();
    if (e != cudaSuccess) return -(int)e;
    e = cudaStreamSynchronize(ctx->stream);
    if (e != cudaSuccess) return -(int)e;
    ctx->round_base += rounds;

    uint32_t flag = 0;
    cudaMemcpyFromSymbol(&flag, d_found_flag, sizeof(flag));
    if (!flag) return 0;

    uint32_t walk = 0;
    long long off = 0;
    cudaMemcpyFromSymbol(&walk, d_found_walk, sizeof(walk));
    cudaMemcpyFromSymbol(&off, d_found_off, sizeof(off));
    if ((int)walk >= ctx->n_walks) return 0;

    // key = seed[walk] + off, with off sign-extended across the 256-bit add.
    const uint64_t *sd = ctx->h_seeds + (size_t)walk * 4;
    uint64_t ext = off < 0 ? ~0ULL : 0ULL;
    uint64_t addend[4] = {(uint64_t)off, ext, ext, ext};
    uint64_t key[4];
    u128 c = 0;
    for (int i = 0; i < 4; i++) {
        c += (u128)sd[i] + addend[i];
        key[i] = (uint64_t)c;
        c >>= 64;
    }
    for (int i = 0; i < 4; i++) {  // little-endian limbs -> big-endian bytes
        uint64_t limb = key[3 - i];
        for (int b = 0; b < 8; b++) found_key_be[i * 8 + b] = (uint8_t)(limb >> (56 - 8 * b));
    }
    return 1;
}

extern "C" int gpu_search_reseed(GpuSearchCtx *ctx, const uint8_t *seeds_be) {
    if (!ctx || !seeds_be) return -1;

    cudaError_t e = cudaSetDevice(ctx->device);
    if (e != cudaSuccess) return -(int)e;

    seeds_be_to_limbs(seeds_be, ctx->n_walks, ctx->h_seeds);

    uint64_t *d_seeds = nullptr;
    if (cudaMalloc(&d_seeds, (size_t)ctx->n_walks * 4 * sizeof(uint64_t)) != cudaSuccess) {
        return -1;
    }
    cudaMemcpyAsync(d_seeds, ctx->h_seeds, (size_t)ctx->n_walks * 4 * sizeof(uint64_t),
                    cudaMemcpyHostToDevice, ctx->stream);

    uint32_t zero = 0;
    cudaMemcpyToSymbolAsync(d_found_flag, &zero, sizeof(zero), 0,
                            cudaMemcpyHostToDevice, ctx->stream);

    int blocks = (ctx->n_walks + 255) / 256;
    k_seed<<<blocks, 256, 0, ctx->stream>>>(d_seeds, ctx->d_pts, ctx->n_walks);
    e = cudaStreamSynchronize(ctx->stream);
    cudaFree(d_seeds);
    if (e != cudaSuccess) return -(int)e;

    ctx->round_base = 0;
    return 0;
}

extern "C" void gpu_search_free(GpuSearchCtx *ctx) {
    if (!ctx) return;
    cudaSetDevice(ctx->device);
    clear_l2_persistent(ctx->stream);
    if (ctx->stream) cudaStreamDestroy(ctx->stream);
    cudaFree(ctx->d_pts);
    cudaFree(ctx->d_gtab);
    free(ctx->h_seeds);
    delete ctx;
}
