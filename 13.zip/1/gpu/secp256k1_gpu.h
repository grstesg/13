#ifndef SECP256K1_GPU_H
#define SECP256K1_GPU_H

#ifdef __cplusplus
extern "C" {
#endif

/* Number of CUDA-capable devices, or a negative CUDA error code. */
int gpu_device_count(void);

/*
 * Writes the name of device `idx` into buf (NUL-terminated).
 * idx must be in [0, gpu_device_count()). Returns 0 on success.
 */
int gpu_device_name(int idx, char *buf, int buflen);

/*
 * Computes hash160(compressed_pubkey(priv)) for n private keys on the GPU.
 * keys:   n * 32 bytes, each a big-endian private key scalar.
 * out20:  n * 20 bytes, filled with the resulting hash160 values.
 * Returns 0 on success, negative CUDA error code on failure.
 * Intended for correctness testing against the CPU reference.
 */
int gpu_hash160_batch(const unsigned char *keys, int n, unsigned char *out20);

/* Opaque search context holding persistent device state across run calls. */
typedef struct GpuSearchCtx GpuSearchCtx;

/*
 * Initializes a search:
 *   target20:  the 20-byte hash160 to find.
 *   seeds_be:  n_walks * 32 bytes, each a big-endian starting private key.
 * Each walk sweeps outward from its seed a block of keys at a time (see
 * gpu_search_keys_per_round), advancing so successive rounds tile the key
 * space contiguously. Note a walk covers keys on *both* sides of its seed, so
 * seeds must be at least gpu_search_keys_per_round()/2 above zero. Returns
 * NULL on failure. n_walks must be a multiple of gpu_search_walk_multiple().
 */
GpuSearchCtx *gpu_search_init(const unsigned char *target20,
                              const unsigned char *seeds_be, int n_walks,
                              int device);

/* Walk counts must be a multiple of this (one walk per thread). */
int gpu_search_walk_multiple(void);

/* Keys each walk covers per round; one field inversion serves the whole block. */
int gpu_search_keys_per_round(void);

/*
 * Advances every walk by `rounds` rounds, checking every key it covers against
 * the target. On match, writes the 32-byte big-endian private key into
 * found_key_be and returns 1. Returns 0 if no match, negative on CUDA error.
 */
int gpu_search_run(GpuSearchCtx *ctx, unsigned long long rounds,
                   unsigned char found_key_be[32]);

/*
 * Replaces every walk's seed with the new n_walks*32 byte big-endian seeds in
 * seeds_be and resets the internal round counter to zero. The target, device,
 * stream and allocated memory are preserved. Returns 0 on success, negative on
 * CUDA error. This is used to implement keyhunt-style random mode where walks
 * are periodically restarted at fresh random points.
 */
int gpu_search_reseed(GpuSearchCtx *ctx, const unsigned char *seeds_be);

void gpu_search_free(GpuSearchCtx *ctx);

#ifdef __cplusplus
}
#endif

#endif /* SECP256K1_GPU_H */
