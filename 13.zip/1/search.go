package main

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"math/big"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

// SearchMode selects how the GPU walks cover the key space.
type SearchMode string

const (
	// ModeSequential starts each walk at a uniformly-random point in the range
	// and sweeps forward contiguously. This is the original caca-gpu behaviour.
	ModeSequential SearchMode = "sequential"
	// ModeRandom re-seeds every walk with a fresh uniformly-random point in the
	// range at regular intervals, like keyhunt's -R / -B random mode.
	ModeRandom SearchMode = "random"
)

// targetWalks is the total number of independent walks searched in parallel
// across all GPUs. Each walk gets its own uniformly-random start in [minKey,
// maxKey] and sweeps outward a block of keys at a time. The total is rounded
// down to a multiple of the kernel's walk granularity.
const targetWalks = 1 << 16

// roundsPerLaunch is how many rounds each walk advances per kernel launch. The
// launch is synchronous, so this bounds how often we can print progress and
// re-check for a match; it trades scheduling overhead against responsiveness.
// One round is already ~17M keys across all walks, so a couple is plenty.
const roundsPerLaunch = 2

// randomReseedLaunches controls how often walks get fresh random seeds in
// ModeRandom. After this many kernel launches every GPU's walks are re-seeded
// from the range, giving keyhunt-style random coverage instead of a fixed
// forward sweep.
const randomReseedLaunches = 10

// gpuSearchResult carries a found key (and the device that found it) or an
// error from a worker goroutine.
type gpuSearchResult struct {
	found     bool
	key       []byte
	deviceIdx int
	err       error
}

// searchForPrivateKey searches for a private key whose compressed public key
// hashes to targetHash160, within [minKey, maxKey], on all available NVIDIA
// GPUs. The search mode selects between a forward sweep from fixed random
// starts (ModeSequential) and periodic re-seeding of every walk with a new
// random point (ModeRandom).
func searchForPrivateKey(minKey, maxKey *big.Int, targetHash160 []byte, mode SearchMode) {
	nGPUs, err := gpuDeviceCount()
	if err != nil || nGPUs < 1 {
		fmt.Printf("%sNo CUDA-capable GPU found: %v%s\n", ColorRed, err, ColorReset)
		return
	}
	for i := 0; i < nGPUs; i++ {
		if name, err := gpuDeviceName(i); err == nil {
			fmt.Printf("%sUsing GPU %d: %s%s%s\n", ColorBlue, i, ColorBoldCyan, name, ColorReset)
		}
	}

	// Inclusive count of keys in the range.
	rangeLen := new(big.Int).Sub(maxKey, minKey)
	rangeLen.Add(rangeLen, big.NewInt(1))

	// Choose a total walk count that is a multiple of the kernel granularity and
	// no larger than the range itself (only relevant for tiny ranges).
	mult := gpuSearchWalkMultiple()
	keysPerRound := gpuSearchKeysPerRound()
	nWalks := targetWalks
	if big.NewInt(int64(nWalks)).Cmp(rangeLen) > 0 && rangeLen.IsInt64() {
		nWalks = int(rangeLen.Int64())
	}
	nWalks = (nWalks / mult) * mult
	if nWalks < mult {
		nWalks = mult
	}

	// Ensure each GPU gets a non-zero multiple of the kernel granularity.
	walksPerGPU := (nWalks / nGPUs / mult) * mult
	if walksPerGPU < mult {
		walksPerGPU = mult
	}
	// Adjust total so every active GPU gets the same count and the total still
	// respects the granularity.
	nWalks = walksPerGPU * nGPUs

	// Give every walk its own uniformly-random starting key in [minKey, maxKey],
	// laid out as nWalks consecutive big-endian 32-byte scalars. A walk covers
	// keys on both sides of its seed, so keep every seed above that half-width;
	// only reachable for the tiny low-numbered puzzles.
	seeds, firstSeed := generateRandomSeeds(nWalks, minKey, rangeLen, keysPerRound)

	modeLabel := "sequential"
	if mode == ModeRandom {
		modeLabel = "random"
	}
	fmt.Printf("%sStarting GPU key search (%s mode) with %d walks x %d keys/round across %d GPU(s)...%s\n",
		ColorBlue, modeLabel, nWalks, keysPerRound, nGPUs, ColorReset)
	fmt.Printf("%sRandom start point (walk 0): %s%s%s\n",
		ColorCyan, ColorBoldCyan, hex.EncodeToString(firstSeed.Bytes()), ColorReset)

	// Initialize one search context per GPU, each owning its slice of seeds.
	searchers := make([]*gpuSearch, nGPUs)
	for i := 0; i < nGPUs; i++ {
		slice := seeds[i*walksPerGPU*32 : (i+1)*walksPerGPU*32]
		s, err := gpuSearchInit(targetHash160, slice, walksPerGPU, i)
		if err != nil {
			for j := 0; j < i; j++ {
				searchers[j].free()
			}
			fmt.Printf("%sGPU %d init failed: %v%s\n", ColorRed, i, err, ColorReset)
			return
		}
		searchers[i] = s
	}
	defer func() {
		for _, s := range searchers {
			s.free()
		}
	}()

	resultCh := make(chan gpuSearchResult, 1)
	var totalKeys atomic.Uint64
	stop := make(chan struct{})
	var wg sync.WaitGroup

	// Start one worker goroutine per GPU.
	for i := 0; i < nGPUs; i++ {
		wg.Add(1)
		go func(idx int, s *gpuSearch) {
			defer wg.Done()
			keysPerBatch := uint64(s.nWalks) * roundsPerLaunch * uint64(keysPerRound)
			launches := 0
			for {
				select {
				case <-stop:
					return
				default:
				}

				// In random mode, refresh the walk seeds periodically so each
				// sweep begins at a new uniformly-random point in the range.
				if mode == ModeRandom && launches > 0 && launches%randomReseedLaunches == 0 {
					newSeeds, _ := generateRandomSeeds(s.nWalks, minKey, rangeLen, keysPerRound)
					if err := s.reseed(newSeeds); err != nil {
						resultCh <- gpuSearchResult{err: err, deviceIdx: idx}
						return
					}
				}
				launches++

				found, key, err := s.run(roundsPerLaunch)
				if err != nil {
					resultCh <- gpuSearchResult{err: err, deviceIdx: idx}
					return
				}
				totalKeys.Add(keysPerBatch)
				if found {
					resultCh <- gpuSearchResult{found: true, key: key, deviceIdx: idx}
					return
				}
			}
		}(i, searchers[i])
	}

	// Progress reporter and result collector.
	startTime := time.Now()
	lastReport := startTime
	var lastKeys uint64
	ticker := time.NewTicker(10 * time.Second)
	defer ticker.Stop()

	// Wait for either a result or a tick. The workers keep running until found,
	// error, or stop is closed.
	var result gpuSearchResult
	gotResult := false
	for !gotResult {
		select {
		case r := <-resultCh:
			gotResult = true
			result = r
		case <-ticker.C:
			now := time.Now()
			tk := totalKeys.Load()
			avg := float64(tk) / now.Sub(startTime).Seconds()
			cur := float64(tk-lastKeys) / now.Sub(lastReport).Seconds()
			lastReport, lastKeys = now, tk
			fmt.Printf("%sChecked %d keys (%.2f Mkeys/sec now, %.2f avg)%s\n",
				ColorCyan, tk, cur/1e6, avg/1e6, ColorReset)
		}
	}

	close(stop)
	wg.Wait()

	if result.err != nil {
		fmt.Printf("%sGPU %d search error: %v%s\n", ColorRed, result.deviceIdx, result.err, ColorReset)
		return
	}
	if result.found {
		reportMatch(result.key, targetHash160)
	}
}

// generateRandomSeeds returns nWalks big-endian 32-byte private keys uniformly
// distributed in [minKey, minKey+rangeLen). The returned firstSeed is the first
// generated key (for display only).
func generateRandomSeeds(nWalks int, minKey, rangeLen *big.Int, keysPerRound int) ([]byte, *big.Int) {
	minSeed := big.NewInt(int64(keysPerRound / 2))
	seeds := make([]byte, nWalks*32)
	var firstSeed *big.Int
	for i := 0; i < nWalks; i++ {
		off, err := rand.Int(rand.Reader, rangeLen)
		if err != nil {
			off = big.NewInt(0)
		}
		key := off.Add(off, minKey)
		if key.Cmp(minSeed) < 0 {
			key.Set(minSeed)
		}
		if i == 0 {
			firstSeed = new(big.Int).Set(key)
		}
		kb := key.Bytes()
		copy(seeds[i*32+32-len(kb):(i+1)*32], kb)
	}
	return seeds, firstSeed
}

// reportMatch prints the found key, verifies its hash160 against the target,
// and writes it to a file (matching the original output format).
func reportMatch(foundKey, targetHash160 []byte) {
	h160, err := privateKeyToHash160(foundKey)
	if err != nil {
		fmt.Printf("%sFound a key but failed to verify it: %v%s\n", ColorRed, err, ColorReset)
		return
	}
	privateKeyHex := hex.EncodeToString(foundKey)
	hash160Hex := hex.EncodeToString(h160)

	fmt.Printf("\n%sMATCH FOUND!%s\n", ColorBoldGreen, ColorReset)
	fmt.Printf("%sPrivate Key: %s%s%s\n", ColorGreen, ColorBoldGreen, privateKeyHex, ColorReset)
	fmt.Printf("%sHash160: %s%s%s\n", ColorGreen, ColorBoldGreen, hash160Hex, ColorReset)

	filename := "found_key_" + hash160Hex[:8] + ".txt"
	content := fmt.Sprintf("Private Key: %s\nHash160: %s\nFound at: %s",
		privateKeyHex, hash160Hex, time.Now().Format(time.RFC3339))
	if err := os.WriteFile(filename, []byte(content), 0600); err != nil {
		fmt.Printf("%sError writing key to file: %s%s\n", ColorRed, err, ColorReset)
	} else {
		fmt.Printf("%sPrivate key saved to file: %s%s%s\n", ColorGreen, ColorBoldGreen, filename, ColorReset)
	}
}
