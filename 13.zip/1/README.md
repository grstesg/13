# Bitcoin Private Key Finder (GPU)

This program searches for Bitcoin Puzzle private keys within a wallet's defined
key range on an **NVIDIA GPU**. The secp256k1 scalar multiplication, SHA-256 and
RIPEMD-160 all run in a CUDA kernel; Go drives the search and reports progress.

## Description

The program works as follows:
1. It prompts the user to enter a wallet number (1-160)
2. It loads the corresponding `hash160` and key range from `data/`
3. It launches a CUDA kernel with ~64K parallel "walks", each starting at a
   uniformly-random key in the range
4. Each walk sweeps a contiguous block of keys per round, hashing every
   compressed public key to a Hash160 and comparing it to the target; a match is
   written to `found_key_<prefix>.txt`

## Prerequisites

- An NVIDIA GPU with a working CUDA driver (verified on an RTX 3050, ~650 Mkeys/s)
- The CUDA toolkit (`nvcc`) and a native Linux Go toolchain (1.21+)
- A C/C++ compiler (cgo links the GPU kernel into the Go binary)

This produces a **Linux** binary; under Windows/WSL run it inside WSL, where the
GPU is reachable through the WSL CUDA driver.

## Compilation

```
make            # nvcc compiles the kernel -> static lib -> cgo links the binary
```

Override the GPU architecture if needed (RTX 3050 = `sm_86`):

```
make CUDA_ARCH=sm_75
```

## Usage

1. Run the program from the project root (it reads files under `data/`):
   ```
   ./bitcoin_finder
   ```
2. Enter a wallet number between 1 and 160 when prompted
3. Choose the search mode:
   - **Sequential** — each walk starts at a uniformly-random point in the range
     and sweeps forward contiguously (original caca-gpu behaviour)
   - **Random** — walks are re-seeded with fresh random points in the range at
     regular intervals, matching keyhunt's `-R` / `-B random` random mode
4. The program searches until a match is found, printing throughput every 10s

## Notes

- Large ranges are effectively unbounded and run until a match is found
- In sequential mode walks sweep outward from fixed random starts and may pass
  the range maximum on huge ranges; this is harmless, since only the in-range
  key produces the target hash
- In random mode the GPU context is preserved across re-seeds, so only the walk
  centres are refreshed; this keeps the overhead low while covering different
  regions of the range like keyhunt's random mode
- Correctness of the GPU math is verified against the CPU reference in
  `gpu_test.go` (run `make test`), including a test that every key a round
  claims to cover is actually checked
- `./bench.sh` rebuilds and reports steady-state throughput; use it rather than
  eyeballing a short run, since the card boosts well above its sustained clock
  for the first minute
