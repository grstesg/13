package main

/*
#cgo CFLAGS: -I${SRCDIR}/gpu
#cgo LDFLAGS: -L${SRCDIR}/gpu -lsecp256k1gpu -L/usr/lib/x86_64-linux-gnu -lcudart -lstdc++
#include <stdlib.h>
#include "secp256k1_gpu.h"
*/
import "C"

import (
	"fmt"
	"unsafe"
)

// gpuDeviceCount returns the number of CUDA devices, or an error.
func gpuDeviceCount() (int, error) {
	n := int(C.gpu_device_count())
	if n < 0 {
		return 0, fmt.Errorf("cudaGetDeviceCount failed (code %d)", -n)
	}
	return n, nil
}

// gpuDeviceName returns the name of CUDA device idx.
func gpuDeviceName(idx int) (string, error) {
	buf := make([]byte, 256)
	rc := int(C.gpu_device_name(C.int(idx), (*C.char)(unsafe.Pointer(&buf[0])), C.int(len(buf))))
	if rc != 0 {
		return "", fmt.Errorf("cudaGetDeviceProperties failed (code %d)", -rc)
	}
	n := 0
	for n < len(buf) && buf[n] != 0 {
		n++
	}
	return string(buf[:n]), nil
}

// gpuSearchWalkMultiple returns the granularity walk counts must be a multiple of.
func gpuSearchWalkMultiple() int {
	return int(C.gpu_search_walk_multiple())
}

// gpuSearchKeysPerRound returns how many keys each walk covers per round.
func gpuSearchKeysPerRound() int {
	return int(C.gpu_search_keys_per_round())
}

// gpuHash160Batch computes hash160(compressed pubkey) for each 32-byte big-endian
// private key on the GPU. Used by the correctness test against the CPU reference.
func gpuHash160Batch(keys [][]byte) ([][]byte, error) {
	n := len(keys)
	if n == 0 {
		return nil, nil
	}
	flat := make([]byte, n*32)
	for i, k := range keys {
		copy(flat[i*32+32-len(k):(i+1)*32], k) // right-align (big-endian, zero-padded)
	}
	out := make([]byte, n*20)
	rc := int(C.gpu_hash160_batch(
		(*C.uchar)(unsafe.Pointer(&flat[0])),
		C.int(n),
		(*C.uchar)(unsafe.Pointer(&out[0]))))
	if rc != 0 {
		return nil, fmt.Errorf("gpu_hash160_batch failed (code %d)", -rc)
	}
	result := make([][]byte, n)
	for i := range result {
		result[i] = out[i*20 : (i+1)*20]
	}
	return result, nil
}

// gpuSearch is a handle to a running GPU search with persistent device state.
type gpuSearch struct {
	ctx       *C.GpuSearchCtx
	nWalks    int
	deviceIdx int
}

// gpuSearchInit uploads the target and per-walk seed keys on the given CUDA
// device, builds the group table and seeds the device points. seedsBE must be
// nWalks*32 bytes (big-endian keys), nWalks a multiple of gpuSearchWalkMultiple().
func gpuSearchInit(target []byte, seedsBE []byte, nWalks int, deviceIdx int) (*gpuSearch, error) {
	if len(target) != 20 {
		return nil, fmt.Errorf("target must be 20 bytes, got %d", len(target))
	}
	if len(seedsBE) != nWalks*32 {
		return nil, fmt.Errorf("seeds must be %d bytes, got %d", nWalks*32, len(seedsBE))
	}
	ctx := C.gpu_search_init(
		(*C.uchar)(unsafe.Pointer(&target[0])),
		(*C.uchar)(unsafe.Pointer(&seedsBE[0])),
		C.int(nWalks),
		C.int(deviceIdx))
	if ctx == nil {
		return nil, fmt.Errorf("gpu_search_init failed for device %d", deviceIdx)
	}
	return &gpuSearch{ctx: ctx, nWalks: nWalks, deviceIdx: deviceIdx}, nil
}

// run advances every walk by `rounds` rounds (rounds*gpuSearchKeysPerRound()
// keys each). If a match is found it returns the 32-byte big-endian key.
func (s *gpuSearch) run(rounds uint64) (found bool, key []byte, err error) {
	out := make([]byte, 32)
	rc := int(C.gpu_search_run(s.ctx, C.ulonglong(rounds), (*C.uchar)(unsafe.Pointer(&out[0]))))
	if rc < 0 {
		return false, nil, fmt.Errorf("gpu_search_run failed (code %d)", -rc)
	}
	if rc == 1 {
		return true, out, nil
	}
	return false, nil, nil
}

// reseed uploads new big-endian 32-byte seeds for every walk and resets the
// internal round counter so the next sweep starts from the new seeds.
func (s *gpuSearch) reseed(seedsBE []byte) error {
	if len(seedsBE) != s.nWalks*32 {
		return fmt.Errorf("reseed seeds must be %d bytes, got %d", s.nWalks*32, len(seedsBE))
	}
	rc := int(C.gpu_search_reseed(s.ctx, (*C.uchar)(unsafe.Pointer(&seedsBE[0]))))
	if rc < 0 {
		return fmt.Errorf("gpu_search_reseed failed (code %d)", -rc)
	}
	return nil
}

func (s *gpuSearch) free() {
	if s.ctx != nil {
		C.gpu_search_free(s.ctx)
		s.ctx = nil
	}
}
