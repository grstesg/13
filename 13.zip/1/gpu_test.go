package main

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"math/big"
	"testing"
)

// TestGPUHash160MatchesReference verifies the GPU pipeline (scalar mult +
// SHA256 + RIPEMD160) produces byte-identical hash160s to the btcec CPU
// reference across a spread of fixed and random keys. This is the correctness
// gate for the GPU field/curve/hash math.
func TestGPUHash160MatchesReference(t *testing.T) {
	if n, err := gpuDeviceCount(); err != nil || n < 1 {
		t.Skipf("no CUDA device available: %v", err)
	}

	keys := [][]byte{
		big.NewInt(1).Bytes(),
		big.NewInt(2).Bytes(),
		big.NewInt(0x1000).Bytes(),
		big.NewInt(0xdeadbeef).Bytes(),
	}
	hexKey := func(s string) []byte {
		b, _ := hex.DecodeString(s)
		return b
	}
	keys = append(keys,
		hexKey("0000000000000000000000000000000000000000000000000000000123456789"),
		hexKey("00000000000000000000000000000000000000000000000fffffffffffffffff"),
		hexKey("000000000000000000000000000000000000000000000000abcdef0123456789"),
		hexKey("8000000000000000000000000000000000000000000000000000000000000000"),
		hexKey("fffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364140"), // n-1
	)
	// Add random keys.
	for i := 0; i < 64; i++ {
		b := make([]byte, 32)
		rand.Read(b)
		b[0] &= 0x7f // keep well below curve order
		keys = append(keys, b)
	}

	got, err := gpuHash160Batch(keys)
	if err != nil {
		t.Fatalf("gpuHash160Batch: %v", err)
	}
	for i, k := range keys {
		want, err := privateKeyToHash160(padPrivateKey(k, 32))
		if err != nil {
			t.Fatalf("reference failed for key %x: %v", k, err)
		}
		if !bytes.Equal(got[i], want) {
			t.Errorf("key %x:\n  gpu  %x\n  want %x", k, got[i], want)
		}
	}
}

// TestGPUSearchFindsKey runs the full search machinery against a tiny range
// containing a known key, confirming the step kernel + seed/found accounting
// recover the right private key.
func TestGPUSearchFindsKey(t *testing.T) {
	if n, err := gpuDeviceCount(); err != nil || n < 1 {
		t.Skipf("no CUDA device available: %v", err)
	}

	// Target key 0x1234ABCD; place lane seeds straddling it so a short walk hits it.
	targetKey := big.NewInt(0x1234ABCD)
	target, err := privateKeyToHash160(padPrivateKey(targetKey.Bytes(), 32))
	if err != nil {
		t.Fatal(err)
	}

	mult := gpuSearchWalkMultiple()
	nWalks := mult // one block worth
	seeds := make([]byte, nWalks*32)
	// Walk 0 starts a few keys below the target so it is covered in round 0.
	start := new(big.Int).Sub(targetKey, big.NewInt(5))
	copy(seeds[32-len(start.Bytes()):32], start.Bytes())
	// Remaining walks start far away (won't match).
	for i := 1; i < nWalks; i++ {
		v := big.NewInt(int64(1000000 + i*int(gpuSearchKeysPerRound())*4))
		copy(seeds[i*32+32-len(v.Bytes()):(i+1)*32], v.Bytes())
	}

	s, err := gpuSearchInit(target, seeds, nWalks, 0)
	if err != nil {
		t.Fatal(err)
	}
	defer s.free()

	found, key, err := s.run(20)
	if err != nil {
		t.Fatal(err)
	}
	if !found {
		t.Fatal("expected to find the key, got no match")
	}
	gotKey := new(big.Int).SetBytes(key)
	if gotKey.Cmp(targetKey) != 0 {
		t.Fatalf("found wrong key: got %x want %x", gotKey, targetKey)
	}
}

// TestGPUSearchReseed verifies that gpu_search_reseed replaces the walk seeds
// and resets the round counter so a target that was out of reach before reseed
// can be found afterwards.
func TestGPUSearchReseed(t *testing.T) {
	if n, err := gpuDeviceCount(); err != nil || n < 1 {
		t.Skipf("no CUDA device available: %v", err)
	}

	targetKey := big.NewInt(0xABCDEF12)
	target, err := privateKeyToHash160(padPrivateKey(targetKey.Bytes(), 32))
	if err != nil {
		t.Fatal(err)
	}

	mult := gpuSearchWalkMultiple()
	nWalks := mult
	seeds := make([]byte, nWalks*32)
	// All walks start far away from the target.
	for i := 0; i < nWalks; i++ {
		v := big.NewInt(int64(0x10000000 + i*gpuSearchKeysPerRound()*4))
		copy(seeds[i*32+32-len(v.Bytes()):(i+1)*32], v.Bytes())
	}

	s, err := gpuSearchInit(target, seeds, nWalks, 0)
	if err != nil {
		t.Fatal(err)
	}
	defer s.free()

	found, _, err := s.run(2)
	if err != nil {
		t.Fatal(err)
	}
	if found {
		t.Fatal("unexpected match before reseed")
	}

	// Reseed walk 0 so the target lies inside its first round.
	reseed := make([]byte, nWalks*32)
	start := new(big.Int).Sub(targetKey, big.NewInt(5))
	copy(reseed[32-len(start.Bytes()):32], start.Bytes())
	for i := 1; i < nWalks; i++ {
		v := big.NewInt(int64(0x20000000 + i*gpuSearchKeysPerRound()*4))
		copy(reseed[i*32+32-len(v.Bytes()):(i+1)*32], v.Bytes())
	}
	if err := s.reseed(reseed); err != nil {
		t.Fatalf("reseed failed: %v", err)
	}

	found, key, err := s.run(2)
	if err != nil {
		t.Fatal(err)
	}
	if !found {
		t.Fatal("expected to find the key after reseed")
	}
	gotKey := new(big.Int).SetBytes(key)
	if gotKey.Cmp(targetKey) != 0 {
		t.Fatalf("found wrong key: got %x want %x", gotKey, targetKey)
	}
}

// TestGPUSearchCoversEveryKey is the anti-gap gate for the group search. A walk
// no longer checks one key per step: each round sweeps a whole block centred on
// its position using the +/- symmetry, then jumps so successive rounds tile the
// key space. A kernel that quietly skipped part of a block, mismapped an offset
// sign, or left a hole at a round boundary would still look fast and still pass
// a single-key test — so assert that every offset a round claims to cover is
// really found, and that consecutive rounds abut exactly.
func TestGPUSearchCoversEveryKey(t *testing.T) {
	if n, err := gpuDeviceCount(); err != nil || n < 1 {
		t.Skipf("no CUDA device available: %v", err)
	}

	perRound := gpuSearchKeysPerRound()
	half := perRound / 2
	mult := gpuSearchWalkMultiple()

	// Seed comfortably above the half-width so negative offsets stay positive.
	seed := new(big.Int).SetInt64(0x40000000)

	// Every offset in round 0, plus the seams into rounds 1 and 2. Round r
	// covers [r*perRound-half, r*perRound+half], so these must be contiguous.
	offsets := make([]int64, 0, perRound+8)
	for d := int64(-half); d <= int64(half); d++ {
		offsets = append(offsets, d)
	}
	offsets = append(offsets,
		int64(perRound)-int64(half),  // first key of round 1
		int64(perRound),              // centre of round 1
		int64(perRound)+int64(half),  // last key of round 1
		int64(2*perRound)-int64(half),// first key of round 2
		int64(2*perRound)+int64(half),// last key of round 2
	)

	// Walk 0 carries the seed; the rest start far away so they cannot match.
	seeds := make([]byte, mult*32)
	sb := seed.Bytes()
	copy(seeds[32-len(sb):32], sb)
	for i := 1; i < mult; i++ {
		v := big.NewInt(int64(0x10000000 + i*perRound*4))
		copy(seeds[i*32+32-len(v.Bytes()):(i+1)*32], v.Bytes())
	}

	for _, d := range offsets {
		want := new(big.Int).Add(seed, big.NewInt(d))
		target, err := privateKeyToHash160(padPrivateKey(want.Bytes(), 32))
		if err != nil {
			t.Fatalf("reference hash160 for offset %d: %v", d, err)
		}

		s, err := gpuSearchInit(target, seeds, mult, 0)
		if err != nil {
			t.Fatalf("offset %d: %v", d, err)
		}
		// Three rounds is enough to reach every offset under test.
		found, key, err := s.run(3)
		s.free()
		if err != nil {
			t.Fatalf("offset %d: %v", d, err)
		}
		if !found {
			t.Fatalf("offset %+d (key %x) was never checked — the search has a gap", d, want)
		}
		if got := new(big.Int).SetBytes(key); got.Cmp(want) != 0 {
			t.Fatalf("offset %+d: found key %x, want %x", d, got, want)
		}
	}
}
